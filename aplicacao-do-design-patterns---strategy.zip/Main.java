//Implementação design patterns - Strategy.
//Sistema de comunicação por chat.


//Participantes: 
//Strategy: É uma interface comum para todas as subclasses, ou para todos os algoritmos que são suportados. 
//O Contexto usa essa interface para chamar uma das subclasses ConcreteStrategy ou um dos algoritmos definidos.


//ConcreteStrategy: A classe concreta que herda da Strategy abstrata está definida como as subclasses ConcreteStrategyA, 
//ConcreteStrategyB e ConcreteStrategyA no diagrama da figura 1.
//Context: É aquele que vai acessar um dos algoritmos das subclasses de interface Strategy.


//Interface do strategy

public abstract class ChatbotStrategy {
    	
    	public String getChatbot() {
		
	}

	public String getlogin() {
		
	}

	public HashMap<Integer, String> getOrigemCadastro(){
	
	}

	public HashMap<String, String> getSegmentos(){
		
	}

	public Calendar getInicioServiço(){
		
	}

	public String getTerminodoserviço(){
	
	}

	public abstract Object saveParameter();

}
//Classe concreta strategy
public class Chatbot extends ChatbotStrategy {

	public Object saveParameter() {
		params = new Object[5];
		params[0] = getchatbot();
		params[1] = getlogin();
		params[2] = getorigemcadastro();
		params[3] = getSegmentos();
		params[4] = getInicioServiço();
		params[5] = getTerminodoserviço();
		return params;
	}
}

//Classe context strategy
public class Contexto {

	private ChatbotStrategy chatbotStrategy = null;

	public void configuraChatbot() {
		chatbotStrategy.saveParameter();
	}

	public ChatbotStrategy getChatbotStrategy() {
		return chatbotStrategy;
	}

	public void setChatbotStrategy(ChatbotStrategy chatbotStrategy) {
		this.chatbotStrategy = chatbotStrategy;
	}

}

public static void main(){
  if(obj.equals(“Chatbot”)){
	params = new Object[5];
	params[0] = getChatbot();
  System.out.System.out.println("Olá, insira seus dados.");
}
  if(obj.equals(“Chatbot”)){
	params = new Object[5];
	params[1] = getLogin();
  System.out.System.out.println("Seja bem vindo!");
 }
  if(obj.equals(“Chatbot”)){
	params = new Object[5];
	params[2] = getOrigemcadastro();
  System.out.System.out.println("Cadastro encontrado!"");
  }
   if(obj.equals(“Chatbot”)){
	params = new Object[5];
	params[3] = getSegmentos();
  System.out.System.out.println("O que posso ajudar?");
 }
  if(obj.equals(“Chatbot”)){
	params = new Object[5];
	params[4] = getInicioServiço();
  System.out.System.out.println("Realizando serviço...");
 }
 if(obj.equals(“Chatbot”)){
	params = new Object[5];
	params[3] = getTerminodoserviço();
  System.out.System.out.println("Serviço realizado com sucesso!" + '\n' + "Posso ajudar em mais alguma coisa?");
 }
}

  